## Overview

Template files used to create new documents and documents with sample content in: 

* [Confluence ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-confluence)
* [Jira ONLYOFFICE integration app](https://github.com/ONLYOFFICE/onlyoffice-jira)
* [HumHub ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-humhub)
* [Liferay ONLYOFFICE Connector](https://github.com/ONLYOFFICE/onlyoffice-liferay)
* [Moodle ONLYOFFICE Integration plugin](https://github.com/ONLYOFFICE/moodle-mod_onlyofficeeditor)
* [Nextcloud ONLYOFFICE integration app](https://github.com/ONLYOFFICE/onlyoffice-nextcloud)
* [Nuxeo ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-nuxeo)
* [ONLYOFFICE Alfresco module package](https://github.com/ONLYOFFICE/onlyoffice-alfresco)
* [ONLYOFFICE App for Pipedrive](https://github.com/onlyoffice/onlyoffice-pipedrive)
* [ownCloud ONLYOFFICE integration app](https://github.com/onlyoffice/onlyoffice-owncloud)
* [Plone ONLYOFFICE integration plugin](https://github.com/onlyoffice/onlyoffice-plone)
