#
# (c) Copyright Ascensio System SIA 2024
#

DOC_SERVER_PUBLIC_URL = "onlyoffice_connector.doc_server_public_url"
DOC_SERVER_JWT_SECRET = "onlyoffice_connector.doc_server_jwt_secret"
DOC_SERVER_JWT_HEADER = "onlyoffice_connector.doc_server_jwt_header"

INTERNAL_JWT_SECRET = "onlyoffice_connector.internal_jwt_secret"